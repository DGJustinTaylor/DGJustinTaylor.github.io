# Wigginator-s-Pinball-Deluxe
The midterm project created for my Unity game development course.

This project is a Unity-made recreation of the classic arcade game pinball! This project has since been completed. There may still be bugs found, but this will not be updated further. (Should be stable, but ball physics may cause crashes)

To run this program you must have the latest version of Unity installed on your computer(earlier versions may prove to be unstable)

I may have included a pre-built executable.

If you'd like to play the game inside Unity, make sure your selected scene is "Main" and then click the play button. Otherwise click the file button in the top left corner and click "Build&Run." This should compile the game for you and run it once finished.

IMPORTANT: All assets provided are free assets given by Untiy, or found freely on the Unity asset store. ALSO: May be very unstable on older machines.
