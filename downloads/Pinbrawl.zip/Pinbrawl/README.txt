To run this program, simply run the executable file titled "Pinball Alpha Build.exe."
The "Pinball Alpha Build_Data" folder is necessary to run the executable. DO NOT DELETE.